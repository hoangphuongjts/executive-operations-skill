# HOÀNG PHƯƠNG — GÓI CHUYỂN GIAO CHATGPT v2 (STAGING)

**Ngày:** 2026-11-07. **Nguồn:** Core v16.0.50 và 16 plugin riêng còn lại. **Chế độ:** chỉ đọc, lập bản sao, không đăng nhập tài khoản đích, không sửa production, không phát sinh phí API.

## 1. Tệp được bàn giao
- `ORIGINAL_BACKUP/`: giữ nguyên ZIP bản gốc để đối chiếu; không ghi đè.
- `STAGING_IMPORT_CANDIDATES/`: 16 ZIP riêng theo định dạng plugin phù hợp hơn; cả 3 plugin manifest cũ được bổ sung `plugin.json`, một Skill bị lỗi YAML trong Core được sửa **trong bản sao**.
- `REPORTS/`: kiểm toán nguồn/thiếu tệp và kết quả QA.
- `MANIFESTS/`: bảng 17 plugin, thứ tự và điều kiện nhập.
- `TESTS/`: 197 ca định tuyến tĩnh Skill, 128 agent role, 108 mã học tập; có chương trình chạy offline `QA_OFFLINE.py`.
- `RECONNECT/`: checklist OAuth/MCP, nhập có phê duyệt và biểu mẫu kiểm thử host.

## 2. Trình tự thao tác ở tài khoản ChatGPT đích
1. Tải ZIP, giải nén và chạy `python TESTS/QA_OFFLINE.py` trên Windows/macOS/Linux có Python 3, không cần cài thêm thư viện (hoặc dùng sẵn `REPORTS/QA_RUN_REPORT.json` nếu không có Python/PyYAML; không tự cài package qua mạng).
2. Mở **ChatGPT → Settings → Plugins → Plugin Creator** (giao diện/quyền có thể khác theo tài khoản). Với tài khoản có chức năng tạo plugin từ archive, chọn **một ZIP** trong `STAGING_IMPORT_CANDIDATES/` mỗi lần. Không tải ZIP tổng hợp 17 plugin vào trình cài một plugin.
3. Bắt đầu từ Core v16.0.50, sau đó những plugin liên quan theo `MANIFESTS/INSTALL_SEQUENCE.csv`. Một ZIP hợp lệ ở mức tĩnh **không bảo đảm** host sẽ chấp nhận hoặc chạy mọi Skill.
4. Sau mỗi lần nhập, ghi chính xác plugin ID mới, release ID mới, số Skill được host nhận và các lỗi vào `RECONNECT/TARGET_ACCOUNT_ACCEPTANCE_TEMPLATE.json`. Plugin ID của tài khoản cũ không phải ID có thể phục hồi bằng sao chép.
5. Đặt tất cả kết nối/API ở trạng thái hạn chế. Chỉ mở quyền và xác thực từng nguồn bằng tài khoản đích, không chép token, cookie, client secret, refresh token. Kiểm thử các tác vụ chỉ đọc trước khi thử hành động ghi.
6. Chạy 108 mã và 128 hồ sơ theo chọn mẫu host; không tuyên bố tất cả 128 là process độc lập. Kiểm thử các Skill được host liệt kê. Chỉ đánh dấu **LIVE_VERIFIED** nếu đọc lại kết quả thật.
7. Với plugin phụ thuộc MCP hoặc Site-backed, dùng `RECONNECT/OAUTH_MCP_MATRIX.json` và làm theo hướng dẫn riêng; 1 plugin Site-bound không có ZIP portable để nhập độc lập.

## 3. Giới hạn
- `STAGING_IMPORT_CANDIDATES` là các **ứng viên cài đặt**, chưa có lượt import trên tài khoản đích.
- 7 tệp `.pyc` cache của 2 plugin không xuất được bằng kênh văn bản; không cần dùng để tái tạo mã nguồn Python; gói này không phải sao lưu byte-for-byte 100%.
- Không có OAuth, API key, tài khoản Google, Nango, proxy, server/Windows runtime hoặc quyền sở hữu plugin của tài khoản nguồn.
- 2 tên Skill trùng giữa `channel-growth-agent-vn` và `content-ai-vietnam`: `free-voiceover`, `voice-selection`. Không đổi tên trong bản sao; kiểm thử chọn đúng plugin khi kích hoạt.
- Một plugin App/Site-backed chỉ có hai manifest, không đủ để sao chép backend Site sang tài khoản khác.
- Một số engine video và nhạc chỉ ở mức Skill hướng dẫn; cần cài runtime ngoài và giấy phép tương ứng. Không có API miễn phí mặc định.

## 4. Kiểm tra
Chạy `python TESTS/QA_OFFLINE.py` từ thư mục gói. Chương trình chỉ đọc, không gọi mạng, không chạy code của plugin. Đọc `REPORTS/QA_RUN_REPORT.json` để xem kết quả khi tạo gói.

**Không sửa, cập nhật, xóa hoặc cài lại plugin Core production trên tài khoản nguồn.**

## 5. Bằng chứng host ở tài khoản nguồn
- Host hiện liệt kê **193/197** Skill portable từ các plugin đã xuất; Core là **92/92**.
- Đã đọc thành công `chidao`, `hoangphuong-v16-active`, `revidapi-reup-video-vn`.
- **4 Skill không có trong danh sách host phiên này**: 3 Skill Nango Gateway và 1 Skill Ebook Library. Không đồng nghĩa chúng không có trong ZIP nguồn.
- Kết quả này **không áp dụng cho tài khoản ChatGPT đích**. Xem `REPORTS/HOST_SOURCE_DISCOVERY_REPORT.json`.
